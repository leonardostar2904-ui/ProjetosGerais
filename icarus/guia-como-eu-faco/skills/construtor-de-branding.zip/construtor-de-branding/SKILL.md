---
name: "construtor-de-branding"
description: "Conduz a criação do branding completo de um cliente, fase a fase: descoberta, estratégia, naming, voz e tom, identidade visual, brandbook e lançamento."
---

# Construtor de Branding

Skill para construir o branding de clientes de ponta a ponta, em fases com aprovação, gerando um Dossiê de Marca vivo que cresce a cada etapa. Metodologia consolidada a partir de: processo de 6 fases (Snapper Studio), manual Branding de José Roberto Martins, Design Thinking (imersão, ideação, prototipação), modelo de Keller e arquitetura de marca (PUCRS), roteiro de Naming em funil e o padrão de entrega do projeto Boma (apresentação de marca + brandbook).

Idioma: sempre Português do Brasil. Nunca usar travessão (use vírgula, dois pontos ou ponto). Sem emojis nos entregáveis.

## Quando usar

Ative quando o usuário disser: "criar branding para [cliente]", "começar marca do cliente X", "retomar branding do X", "próxima fase do branding", "montar brandbook", "definir propósito, público, concorrência, identidade visual ou voz da marca" de um cliente.

## Princípios inegociáveis

1. **Ordem correta: posicionamento, depois nome, depois identidade visual.** Nunca desenhar antes de decidir o que a marca defende.
2. **Marca é sistema, não logotipo.** Ela promete e entrega. Toda promessa precisa ser verificável na operação do cliente (atendimento, pós venda, entrega). Se o cliente não consegue entregar, a promessa sai.
3. **Diferença desejada, não diferença qualquer.** Posicionar é escolher e renunciar: uma posição bem definida abre mão de outra.
4. **O juiz é o cliente final.** Decisões são defendidas pelo Farol Estratégico (posicionamento aprovado), nunca por "gostei / não gostei".
5. **Nome sem registro não é patrimônio.** Todo nome passa por checagem de anterioridade no INPI, domínio e redes.
6. **Toda cor, fonte e símbolo tem justificativa estratégica** escrita (como na Boma: verde = segurança, laranja = calor humano).
7. **Comitê pequeno.** 3 a 5 decisores do lado do cliente. Comitê grande gera marca neutra.

## Modo de operação

### Iniciar um cliente novo
1. Pergunte (AskUserQuestion, se disponível): nome do cliente, tipo de projeto (nova marca, rebrand, refresh), escopo contratado (quais fases) e o material que já existe (briefing, respostas de formulário, site, redes, apresentações).
2. Crie o **Dossiê de Marca** do cliente como documento vivo (tipo Docs quando disponível; senão arquivo `dossie-[cliente].md`). Estrutura no final desta skill.
3. Mostre o plano do projeto em tabela (Fase | Prazo estimado | Entregável | Aprovação do cliente) usando os prazos de referência abaixo.

### Retomar um cliente
Leia o dossiê existente, identifique a última fase aprovada e proponha a próxima. Nunca refaça fase aprovada sem pedido explícito.

### Regra de avanço
Cada fase termina com: entregável pronto, lista de decisões que o cliente precisa aprovar e perguntas em aberto. Só avance quando o usuário confirmar a aprovação. Se faltar dado, produza a melhor versão possível marcando as premissas como [PREMISSA] para validar.

## Prazos de referência

| Fase | Prazo típico |
|---|---|
| 0. Kickoff e diagnóstico | 1 semana |
| 1. Descoberta e pesquisa | 1 a 2 semanas |
| 2. Estratégia de marca | 2 a 3 semanas |
| 3. Identidade verbal (naming, voz, tagline) | 1 a 2 semanas |
| 4. Identidade visual | 4 a 6 semanas |
| 5. Brandbook e apresentação | 2 a 4 semanas |
| 6. Ativação e lançamento | 1 semana ou mais |

Nova marca ou refresh: cerca de 4 meses. Rebrand completo: 8 a 16 semanas, podendo chegar a 12 meses com pontos físicos. O prazo depende mais da velocidade de feedback do cliente do que da agência: deixe isso explícito no plano.

---

## Fase 0. Kickoff e diagnóstico

Objetivo: descobrir o que o cliente realmente precisa (às vezes é só ajuste de mensagem, não rebrand).

- Classifique: nova marca, refresh (ajuste visual e verbal) ou rebrand (reposicionamento).
- Auditoria rápida da marca atual, se existir: nome, logo, cores, site, redes, tom, experiência de atendimento, avaliações de clientes.
- Mapeie o time do cliente: decisor final, pessoa criativa, pessoa analítica, quem consolida feedback, gestor do projeto.
- Liste o escopo de entregáveis desde já (papelaria, social, site, sinalização, embalagem, fotografia, kit de boas vindas).

Entregável: diagnóstico de 1 página + plano do projeto + questionário de briefing (modelo abaixo) enviado ao cliente.

## Fase 1. Descoberta e pesquisa ("ver a marca de fora")

1. **Questionário de briefing** respondido pelo cliente.
2. **Imersão com pessoas reais**: roteiro de entrevista em 4 etapas (criar conexão, introduzir o assunto, buscar histórias, explorar emoções). Perguntas abertas: "Como você se sente quando...", "O que você faz quando...", "Como gostaria que fosse...". Entreviste sócios, equipe e clientes. Não sugira respostas.
3. **Análise de concorrência** (use WebSearch quando o usuário der nomes ou setor e cidade): para 3 a 6 concorrentes, registre em tabela: promessa, público, tom de voz, cores e tipografia, preço percebido, pontos fortes, pontos fracos, espaço que ninguém ocupa.
4. **Mercado e pontos de contato**: onde o cliente encontra a marca (ciclo de contatos: antes, durante e depois da compra) e quais são os "momentos da verdade" onde a marca pode perder o cliente.
5. **Síntese**: SWOT da marca, insights principais, padrões encontrados e o desafio reformulado em uma frase "Como podemos...".

Entregável: Relatório de Descoberta com tabela de concorrentes, SWOT, mapa de pontos de contato e 5 a 8 insights.

## Fase 2. Estratégia de marca

Se já existir a skill `hias-brand-strategy` e o cliente tiver respondido o briefing, pode usá-la como motor desta fase e depois trazer o resultado para o dossiê.

1. **Propósito, missão, visão e valores** em frases curtas.
   - Propósito: por que a marca existe além do lucro (1 frase).
   - Missão: o que faz, para quem e como (1 frase).
   - Visão: onde quer chegar em 5 a 10 anos (1 frase).
   - Valores: 3 a 5, cada um com definição de uma linha e um comportamento observável ("na prática, isso significa...").
2. **Golden Circle**: Por quê, Como, O quê (modelo Boma).
3. **Público**:
   - Público alvo (quem se quer alcançar) e persona (retrato do cliente ideal).
   - 2 a 3 personas no formato: nome, bairro/cidade, idade, personalidade, valores, dores, desejos, comportamento de compra, e "como a marca ajuda". Inclua ao menos um usuário extremo.
   - Mapa de empatia da persona principal: pensa e sente, ouve, vê, fala e faz, dores, ganhos.
4. **Posicionamento**: declaração no formato "Para [público] que [necessidade], [marca] é [categoria] que [benefício principal], porque [razão para acreditar]. Diferente de [alternativa], nós [diferencial]." Teste com três perguntas: é verdadeiro? é relevante? é diferente? Liste também o que a marca renuncia.
5. **Promessa de marca** (1 frase) e **proposta de valor**.
6. **Personalidade**: 3 a 4 traços (ex.: Sofisticação, Confiança, Excelência) com o que é e o que não é cada traço. Arquétipo opcional.
7. **Narrativa da marca**: história curta de origem e transformação (até 150 palavras).
8. **Arquitetura de marca**, se houver mais de um produto: monolítica, endossada ou independente.

Validação: avalie a estratégia com os Seis Chapéus (fatos, pontos fortes, emoção, riscos, criatividade, controle) antes de levar ao cliente.

Entregável: Plataforma de Marca (1 documento), este é o Farol Estratégico de todas as fases seguintes.

## Fase 3. Identidade verbal

### 3.1 Naming (só se o projeto incluir nome)
Se existir a skill `naming`, use-a para gerar opções. Em qualquer caso, siga o funil:
1. Farol: releia posicionamento e personalidade.
2. Territórios: gere 80 a 100 palavras em 4 quadrantes (descritivo, simbólico/metafórico, abstrato/neologismo, composto/acrônimo).
3. Alquimia: combine prefixos, radicais e sufixos em 30 a 50 candidatos.
4. Peneira grossa (usabilidade): fácil de falar, soletrar, digitar e lembrar; sem conotação negativa em português, inglês e espanhol. Resultado: 10 a 15 nomes.
5. Matriz de pontuação (0 a 3 por critério): memorabilidade, diferenciação, conexão estratégica, flexibilidade para crescer. Resultado: 3 finalistas.
6. Pódio: defesa conceitual de cada finalista + checklist de proteção: busca no INPI na classe correta, domínio .com.br e .com, handles nas redes. Sempre recomendar validação final com especialista em propriedade industrial.

Lembrete para o cliente: o melhor nome raramente é o que soa mais familiar; nomes menos convencionais têm mais chance de registro.

### 3.2 Tagline
3 a 5 opções curtas, ligadas à promessa. Indicar a recomendada e por quê.

### 3.3 Voz e tom
- Voz (constante): 3 atributos com "é / não é" (ex.: confiante, não arrogante).
- Tom (varia por situação): tabela com contextos (post institucional, anúncio, atendimento, reclamação, cobrança, boas vindas) e como a marca fala em cada um.
- Vocabulário: palavras que usamos, palavras que evitamos.
- 3 exemplos de frases no tom certo e 3 no tom errado.

Entregável: Guia de Identidade Verbal.

## Fase 4. Identidade visual

A skill não substitui o designer: ela gera a direção criativa e o briefing de design, e pode prototipar conceitos simples (paleta, pares tipográficos, moodboard descrito, rascunhos de símbolo em SVG) para acelerar a conversa.

1. **Conceito visual central**: a ideia que amarra tudo (ex.: Boma, "imóvel parado é água estagnada, a marca traz o movimento", daí o símbolo de ondas).
2. **Moodboard** descrito em 2 ou 3 direções diferentes (referências, texturas, fotografia, sensação), cada uma ligada a um traço de personalidade.
3. **Logotipo e símbolo**: briefing com assinaturas necessárias (logotipo + símbolo, só logotipo, só símbolo), área de proteção, redução mínima, usos incorretos.
4. **Paleta de cores**: 4 a 6 cores com HEX, RGB, CMYK e referência Pantone quando possível, papel de cada cor (primária, apoio, destaque, fundo) e justificativa estratégica de cada uma. Verificar contraste de leitura.
5. **Tipografia**: 1 fonte de destaque + 1 de texto, com hierarquia (título, subtítulo, corpo, destaque em itálico), pesos, espaçamentos e usos incorretos. Priorizar fontes com licença livre (Google Fonts) ou avisar sobre licença.
6. **Elementos gráficos e fotografia**: grafismos derivados do símbolo, estilo de imagem, o que evitar.
7. **Checagem de diferenciação**: a identidade não pode se confundir com a de nenhum concorrente mapeado na Fase 1.

Nunca copiar ou imitar marca, personagem ou identidade existente.

Entregável: Direção de Arte + Briefing de Design (para o designer executar) + protótipo de paleta e tipografia.

## Fase 5. Brandbook e apresentação de marca

Dois entregáveis, no padrão Boma:

**Apresentação de marca** (para reunião de aprovação; use o tipo Slides quando disponível ou a skill `hias-presentation` quando for entrega Hias): capa; Golden Circle (Por quê, Como, O quê); promessa em destaque; público e personas; traços de personalidade; tom de voz; cores com justificativa; aplicações (mockups: outdoor, mobiliário urbano, cartão, perfil e posts de Instagram); ativação; encerramento.

**Brandbook** (manual de uso): sumário; 01 Assinaturas (logotipo + símbolo, logotipo, símbolo, área de proteção, redução mínima em px e cm, usos incorretos); 02 Cores (conceito da paleta, valores de referência, usos corretos e incorretos); 03 Tipografia (famílias, hierarquia, usos incorretos); 04 Aplicações; 05 Contato. Acrescentar a seção de voz e tom quando a identidade verbal fizer parte do escopo.

**Guia de navegação do Drive** para o cliente: pastas Fontes, Logos (CMYK para impresso, RGB para digital; PNG com fundo transparente, SVG vetorial), Apresentação de Marca e Brandbook.

## Fase 6. Ativação e lançamento

1. **Lançamento interno**: treinamento rápido da equipe do cliente (o que a marca promete e como cada pessoa entrega isso no dia a dia).
2. **Plano de rollout**: checklist de todos os pontos de contato a atualizar (site, redes, assinatura de e-mail, papelaria, fachada, uniformes, contratos, WhatsApp, Google Meu Negócio), com dono e prazo.
3. **Momentos da verdade**: para os 3 principais pontos de contato, defina o padrão de experiência e o que fazer quando algo dá errado.
4. **Ativação de relacionamento** (opcional): gesto que materializa a promessa (ex.: caixa presente de boas vindas da Boma).
5. **Lançamento digital** com o Círculo de Influência: conteúdo central (vídeo, texto longo que apresenta a nova marca), conteúdo focado (cortes, carrossel, reels, frases) e conteúdo colaborativo (respostas a comentários e dúvidas). Entregar bio do Instagram, 9 primeiras ideias de post com legenda e 3 sequências de stories.

Entregável: Plano de Lançamento em tabela Tarefa | Responsável | Prazo | Resultado esperado.

## Fase 7. Gestão e mensuração (pós lançamento)

Defina indicadores de brand equity para acompanhar a marca a cada 3 ou 6 meses: lembrança (top of mind e awareness), preferência, recompra e indicação, capacidade de cobrar preço premium, engajamento e sentimento nas redes, reclamações. Uma marca que só vende com desconto está virando commodity: sinal de alerta.

---

## Modelo: questionário de briefing

1. Conte a história da empresa: como começou e por quê.
2. O que vocês vendem e qual problema isso resolve?
3. Quem é o cliente ideal? Descreva uma pessoa real.
4. Por que os clientes escolhem vocês e não o concorrente?
5. Por que um cliente deixaria de comprar de vocês?
6. Quem são os 3 principais concorrentes? O que admiram e o que criticam neles?
7. Quais marcas (de qualquer setor) admiram e por quê?
8. Se a marca fosse uma pessoa, como ela seria, se vestiria e falaria?
9. Quais 3 palavras vocês querem que o cliente associe à marca? E quais nunca?
10. Onde querem estar em 5 anos?
11. O que a marca atual faz bem e o que incomoda? (se existir)
12. Quais valores são inegociáveis no negócio?
13. Há restrições (cores, nomes, elementos que devem permanecer)?
14. Quem decide e quem precisa aprovar cada etapa?
15. Quais materiais precisam ser entregues ao final?

## Estrutura do Dossiê de Marca

```
# Dossiê de Marca: [Cliente]
Status: Fase atual | Última aprovação | Próximo passo
## 0. Diagnóstico e escopo
## 1. Descoberta (briefing, entrevistas, concorrência, SWOT, insights)
## 2. Plataforma de Marca (propósito, missão, visão, valores, Golden Circle, personas, posicionamento, promessa, personalidade, narrativa, arquitetura)
## 3. Identidade Verbal (nome, tagline, voz e tom)
## 4. Identidade Visual (conceito, cores, tipografia, símbolo, fotografia)
## 5. Brandbook e Apresentação (links)
## 6. Lançamento (rollout, momentos da verdade, conteúdo)
## 7. Indicadores
## Decisões aprovadas (data, decisão, quem aprovou)
## Pendências e premissas a validar
```

Atualize o bloco Status e a lista de Decisões ao fim de cada fase.

## Checklist de qualidade antes de entregar qualquer fase

- [ ] Tudo o que foi produzido se conecta ao posicionamento aprovado?
- [ ] A promessa é verdadeira e a operação do cliente consegue entregar?
- [ ] Há algo que um concorrente poderia assinar igual? Se sim, reescrever.
- [ ] Premissas não confirmadas estão marcadas?
- [ ] Nenhum travessão e nenhum emoji no texto final.
- [ ] A fase termina com lista clara de aprovações pendentes do cliente.